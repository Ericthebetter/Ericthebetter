# Instagram Unfollow Unfollowers Bot
An Simple Instagram bot that unfollows people you have been following that don't Follow you back. It uses the Instagram API and is working as of 2021 completely.

# Instructions
1. Clone this repository using git on command Prompt/Terminal. Download Git [here](https://git-scm.com/downloads)
* `git clone https://github.com/wrecker3000/InstaUnfollow`


2. Then Move to the new folder youurself or by  command
* `cd InstaUnfollow`

3. Run this command to install requirements of bot.
* `pip -r requirements.txt`

4. Open keys-ig.py using text editor or editor of your preference.

5. Put Your Instagram Username and Password of the ID you want to remove unfollowers from.

6. now run this command in command Prompt/terminal.
* `python main.py`
7. Bot will do its work Select y/n for yes/no when asked to proceed with action.

* All the IDs that Bot unfollows will be listed in unfollwers-log.csv. If you want to follow any of them later, you can search and follow again by searching their username.

## That's It. All done right and proper. Hope you like it. For any queries or suggestions feel free to raise an issue on github or Contact me on Telegram @raiden57.



